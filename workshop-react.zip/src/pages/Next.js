import style from './Next.module.css'

function Next() {
  return (
    <div className={style.home_page}>
      <h1>
        Bem vindo, ao <span>NEXT!</span>
      </h1>
    </div>
  );
}

export default Next;